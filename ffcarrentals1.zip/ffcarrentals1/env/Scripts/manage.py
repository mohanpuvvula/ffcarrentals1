import os
import sys
import importlib


def main():
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ffcarrentals1.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Make sure it is installed and "
            "available on your PYTHONPATH environment variable or "
            "in your virtual environment."
        ) from exc

    # Manually reload importlib to use the modified version
    importlib.reload(importlib)

    execute_from_command_line(sys.argv)


if __name__ == '__main__':
    main()
