from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ffcarrentals1', '0018_alter_quote_table'),
    ]

    operations = [
        migrations.AlterModelTable(
            name='quote',
            table='custom_quote_table',
        ),
    ]
